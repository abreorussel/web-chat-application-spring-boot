package com.nse.redis.model;

public enum MessageStatus {
	 RECEIVED, DELIVERED
}
